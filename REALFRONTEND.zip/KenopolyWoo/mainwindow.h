#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMouseEvent>
#include <QPushButton>
#include <sstream>



class location{
public:
    location();
    std::string Name;
    bool isProperty = true; // unless specified otherwise
    bool isUtility = false; // unless specified otherwise - utilities and railroads calculate rent differently
    bool isRailroad = false; // unless specified otherwise - they also cannot have houses/hotels
    bool isMonopoly = false; // is true if all tiles of the same color are owned by the same player
    std::string Color = "Blank";
    int Price;
    int Rent; //rent 0 house
    int Rent1H; // rent 1 house
    int Rent2H;
    int Rent3H;
    int Rent4H;
    int RentH; //rent hotel
    int MortgageVal;
    int HouseP;
    bool Owned = false;
    int OwnerID = 4; // BANK 'OWNS' ALL PROPERTIES AT THE START OF GAME
    int numHouse = 0;
    bool Hotel = false;
    bool isMortgaged = false;
    bool inTrade = false;
    int NumSetOwned; // NUM OF SAME SET PROPS OWNED
    float PlayerRadius; // AVERAGE DISTANCE OF PLAYERS (NOT INCLUDING OWNER) FROM PROPERTY


};

class player: public location{

public:
    player();
    int PID=0;
    int Bal = 1500;
    int location = 0;
    int DiceRoll = 0;
    bool TiedRoll = true; // bool to help determine first turn - if two players have the same dice roll before game this will be set to true
    std::string PlayerName;
    std::string tempName;
    bool InJail = false; // bool to see if player is in jail
    int JailTurns = 0; // number of turns in jail
    int RemainingPlayers = 4; // used to determine when the game ends./// maybe the bank owns this?
    bool GOOJF = false; // GET OUT OF JAIL FREE CARD
    int DoublesCount = 0; // TO CHECK IF PLAYER HAS ROLLED 3 DOUBLES IN A ROW
    bool Bankrupt = false;
    bool Bot = false;
    void RollDice (std::vector <player> PlayerArray[], class location Board[], int Player, bool FirstRoll);
    void MovePlayer (std::vector <player> PlayerArray[], class location Board[], int Player, bool Doubles, bool FirstRoll);
    void PayRent (std::vector <player> PlayerArray[], class location Board[], int Player);
    void PayRentUtility (std::vector <player> PlayerArray[], class location Board[], int Player);
    void BuyProperty (std::vector <player> PlayerArray[], class location Board[], int Player);
    void TurnInJail (std::vector <player> PlayerArray[], class location Board[], int Player);
    void PassedGO (std::vector <player> PlayerArray[], class location Board[], int Player);
    void CheckMonopoly (class location Board[], int Prop); // CHECKS FOR A MONOPOLY AFTER A PLAYER GAINS A CARD
    void UtilRRMonopoly (class location Board[], int Prop, int Player); //  CHECKS FOR UTILITY OR RAILROAD MONOPOLY
    void PropDetails (class location Board[], int Prop); // DISPLAYS PROPERTY DETAILS
    void MyProperties (std::vector <player> PlayerArray[], class location Board[], int Player); // DISPLAYS OWNED PROPERTIES
    void UpdateProp (std::vector <player> PlayerArray[], class location Board[], int Player);
    void BuySellHouseHotel (std::vector <player> PlayerArray[], class location Board[], int Player, int Prop, bool Buying);
    void MortgageProp (std::vector <player> PlayerArray[], class location Board[], int Player, int Prop);
    void UtilRRDetails (class location Board[], int Prop);
    void Chance (std::vector <player> PlayerArray[], class location Board[], int Player, bool Doubles);
    void CommunityChest(std::vector <player> PlayerArray[], class location Board[], int Player);
    bool CheckBankrupt (std::vector <player> PlayerArray[], class location Board[], int Player, int Amt, int Payee);
    void DisplayBoard (std::vector <player> PlayerArray[], class location Board[], int Prop);
    void Trade(std::vector <player> PlayerArray[], class location Board[], int Player);
    bool PossibleMonopoly (std::vector <player> PlayerArray[], class location Board[], int Player, int Prop, int ManyProps); // CHECKS IF A PLAYER RECEIVING A PROPERTY WILL RESULT IN A MONOPOLY
    void BOTTrade (std::vector <player> PlayerArray[], class location Board[], int Player, int Prop);
    void BOTBuyHouse (std::vector <player> PlayerArray[], class location Board[], int Player, int Prop, bool Set);
    void BOTMortgage (std::vector <player> PlayerArray[], class location Board[], int Player, int Prop, bool Mortgage);
    int BOTChooseHouseProp (std::vector <player> PlayerArray[], class location Board[], int Player);
    bool BOTBankrupt (std::vector <player> PlayerArray[], class location Board[], int Player, int Amt, int Payee);
    void BOTSellHouse (std::vector <player> PlayerArray[], class location Board[], int Player, int Prop, bool Set);


};


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT


public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void Start_Game();
    void Copy_Input();
    void Continue_Game();
    void Set_Player_Num();
    void Set_Player_Names();
    std::string input ="base";
    bool player_num_done=false;
    int playerNum=0;
    int turnCount=0;
    int RemainingPlayers = 4;
    std::vector <player> PlayerArray;
    bool player_name_done=false;

protected:
        //bool eventFilter(QObject *watched, QEvent *event); // important!!!
private slots:
        void on_ContinueButton_clicked();

private:
    Ui::MainWindow * ui;
};



#endif // MAINWINDOW_H
