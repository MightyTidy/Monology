#pragma once

#include <chrono>
#include <thread>
#include <cstdlib>
#include "jackCode.h"


namespace TestBoard {

	using namespace std::this_thread; // sleep_for, sleep_until
	using namespace std::chrono; // nanoseconds, system_clock, seconds

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
		//Rectangle letsGo = Rectangle(340, 500, 20, 20);
		//460 start point
		//420 board(1)
		//380 board(2)
		//340 board(3)


	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}



	private: System::Windows::Forms::Label^ label1;



	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ textBox3;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::PictureBox^ pictureBox2;
	private: System::Windows::Forms::Label^ label3;

	protected:

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(310, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(205, 28);
			this->label1->TabIndex = 3;
			this->label1->Text = L"Kenopoly Woooo!";
			this->label1->Click += gcnew System::EventHandler(this, &MyForm::label1_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(196, 52);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(545, 560);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox1->TabIndex = 8;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &MyForm::pictureBox1_Click);
			this->pictureBox1->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &MyForm::pictureBox1_Paint);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(898, 103);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(77, 51);
			this->button2->TabIndex = 9;
			this->button2->Text = L"Start";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(978, 36);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(78, 28);
			this->label2->TabIndex = 6;
			this->label2->Text = L"Result\r\n";
			// 
			// textBox3
			// 
			this->textBox3->ForeColor = System::Drawing::SystemColors::WindowText;
			this->textBox3->Location = System::Drawing::Point(856, 36);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(100, 20);
			this->textBox3->TabIndex = 5;
			this->textBox3->Text = L"Enter Text Here!";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(747, 19);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(103, 52);
			this->button1->TabIndex = 1;
			this->button1->Text = L"Add";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// textBox2
			// 
			this->textBox2->ForeColor = System::Drawing::SystemColors::WindowText;
			this->textBox2->Location = System::Drawing::Point(631, 36);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(100, 20);
			this->textBox2->TabIndex = 4;
			this->textBox2->Text = L"Enter Text Here!";
			// 
			// pictureBox2
			// 
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(655, 521);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(23, 22);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox2->TabIndex = 10;
			this->pictureBox2->TabStop = false;
			this->pictureBox2->Click += gcnew System::EventHandler(this, &MyForm::pictureBox2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(983, 114);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(49, 20);
			this->label3->TabIndex = 11;
			this->label3->Text = L"Roll #\r\n";
			this->label3->Click += gcnew System::EventHandler(this, &MyForm::label3_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1080, 624);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	int result = System::Convert::ToInt16(textBox2->Text) + System::Convert::ToInt16(textBox3->Text);

	label2->Text = System::Convert::ToString(result);
}

private: System::Void pictureBox1_Click(System::Object^ sender, System::EventArgs^ e) {
}

private:
	void DrawRectangle()
	{
		System::Drawing::Pen^ myPen =
			gcnew System::Drawing::Pen(System::Drawing::Color::Red);
		System::Drawing::Graphics^ formGraphics;
		formGraphics = this->CreateGraphics();
		//formGraphics->FillRectangle(Brushes::Blue, Rectangle(800, 200, 30, 30));
		Rectangle woo = Rectangle(725, 300, 30, 30);
		
		formGraphics->DrawRectangle(myPen, woo);

		woo.Offset(100, 100);

		delete myPen;
		delete formGraphics;
	}

private:
	void DrawEllipse()
	{
		System::Drawing::Pen^ myPen =
			gcnew System::Drawing::Pen(System::Drawing::Color::Red);
		System::Drawing::Graphics^ formGraphics;
		formGraphics = this->CreateGraphics();
		formGraphics->DrawEllipse(myPen, Rectangle(0, 0, 200, 300));
		delete myPen;
		delete formGraphics;
	}


private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	//DrawRectangle();
	//DrawEllipse();

	//int numOfSpaces = 5; // Default dice roll of 5 for testing

	int numOfSpaces = rand() % 11 + 2;

	label3->Text = System::Convert::ToString(numOfSpaces);

	/*

	int currentX = pictureBox2->Location.X;

	int currentY = pictureBox2->Location.Y;

	while (numOfSpaces > 0) {

		if (currentX > 255 && currentY == 521) { // 1st side, going left
			currentX = currentX - 40;
		}
		else if (currentX == 255 && currentY > 121) { //2nd side, going up
			currentY = currentY - 40;
		}
		else if (currentX < 655 && currentY == 121) { //3rd side, going right
			currentX = currentX + 40;
		}
		else if (currentX == 655 && currentY < 621) { //4th side, going down
			currentY = currentY + 40;
		}

		numOfSpaces--;

	}

	//make point
	Point woowoo = Point(currentX, currentY);

	//pass ^that point to picturebox location
	pictureBox2->Location = woowoo;

	*/

	

	while (numOfSpaces > 0) {

		int currentX = pictureBox2->Location.X;

		int currentY = pictureBox2->Location.Y;

		if (currentX > 255 && currentY == 521) { // 1st side, going left
			currentX = currentX - 40;
		}
		else if (currentX == 255 && currentY > 121) { //2nd side, going up
			currentY = currentY - 40;
		}
		else if (currentX < 655 && currentY == 121) { //3rd side, going right
			currentX = currentX + 40;
		}
		else if (currentX == 655 && currentY < 621) { //4th side, going down
			currentY = currentY + 40;
		}

		//make point
		Point woowoo = Point(currentX, currentY);

		//pass ^that point to picturebox location
		pictureBox2->Location = woowoo;

		numOfSpaces--;

		sleep_for(nanoseconds(300000000));
	}

	

	


}

private: System::Void pictureBox1_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
	//Rectangle letsGo = Rectangle(340, 500, 20, 20);
	//460 start point
	//420 board(1)
	//380 board(2)
	//340 board(3)

	

	Rectangle letsGo = Rectangle(460, 500, 20, 20);

	e->Graphics->FillRectangle(Brushes::Blue, letsGo);

	letsGo.Offset(-40, 0);

	//e->Graphics->FillRectangle(Brushes::Blue, letsGo);


	//letsGo.X = 420;

	//e->Graphics->FillRectangle(Brushes::Blue, letsGo);

	

	//for (int i = 420; i >= 60; i-=40) {
	//	e->Graphics->FillRectangle(Brushes::Blue, Rectangle(i, 500, 20, 20));
	//}


	//letsGo.X = 60;
	//letsGo.Y = 460;
	//e->Graphics->FillRectangle(Brushes::Blue, letsGo);
}

private: System::Void pictureBox2_Click(System::Object^ sender, System::EventArgs^ e) {

	//make point
	Point woowoo = Point(460, 500);

	//pass ^that point to picturebox location
	pictureBox2->Location = woowoo;


}
private: System::Void label3_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
}
};
}

/*
Point p = MyPictureBox.Location;
[4:17 PM]
p.X += MyRandom.Next(1, 4); //Move forward either 1, 2, 3 or 4 spaces at random

*/


