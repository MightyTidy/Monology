#include "MyForm.h"

using namespace System;

using namespace System::Windows::Forms;

[STAThread]

// https://www.simplilearn.com/tutorials/cpp-tutorial/cpp-gui?source=sl_frs_nav_playlist_video_clicked#:~:text=To%20develop%20C%2B%2B%20GUI%20or,for%20the%20C%2B%2B%20GUI%20application.
// ^look at this for buttons to do stuff (roll dice, etc.)

// https://www.youtube.com/watch?v=LF1cI7zeFm4
// ^more gui stuffs

void main(array<String^>^ args)

{

    Application::EnableVisualStyles();

    Application::SetCompatibleTextRenderingDefault(false);

    TestBoard::MyForm form;

    Application::Run(% form);

}