#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //qApp->installEventFilter(this);
    ui->setupUi(this);
    Start_Game();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::Copy_Input(){
  QString data = ui->InputBox1->toPlainText(); //turns data into c++ string type;
  input = data.toLocal8Bit().constData(); // supposed to store string in data member which I declared here

}
QLabel * MainWindow::getPlayerLabel(int PID){
    if(PID==0){
        QLabel * ptr = ui->Player1Label;
        return ptr;
    }
    if(PID==1){
        QLabel * ptr = ui->Player2Label;
        return ptr;
    }
    if(PID==2){
        QLabel * ptr = ui->Player3Label;
        return ptr;
    }
    if(PID==3){
        QLabel * ptr = ui->Player4Label;
        return ptr;
    }
    else{
        QLabel * ptr = ui->Player1Label;
        return ptr;
    }


}

void MainWindow::Start_Game(){
    ui->BuyButton->setVisible(false);
    ui->SkipButton->setVisible(false);

    //ui->Player1Label->setFrameStyle(QFrame::Panel | QFrame::Sunken);
   // ui->Player1Label->setGeometry(10,10,30,8); //oh yeah baby this is how we move stuff
    ui->textConsole->setText("How many players are there? Enter it in the box below and press Continue: ");





    //now we need to make animation.

}
bool MainWindow::AroundCorner(int PID,int NumOfSpaces){
   return true;

}
void MainWindow::on_SkipButton_clicked(){
    ui->ContinueButton->setVisible(true);
}

void MainWindow::payPlayer(int location, int utilityRent){
    if(utilityRent == 0){
        PlayerArray[turnCount].Bal-=BoardVec[PlayerArray[turnCount].location].Rent;
        PlayerArray[BoardVec[PlayerArray[turnCount].location].OwnerID].Bal += BoardVec[PlayerArray[turnCount].location].Rent;
    }
    else{
        PlayerArray[turnCount].Bal -= utilityRent;
        PlayerArray[BoardVec[PlayerArray[turnCount].location].OwnerID].Bal += utilityRent;
    }
    update_Summary();
}

bool MainWindow::looping(int PID, int NumOfSpaces ){
    if (PlayerArray[PID].location + NumOfSpaces > 40){
        int remain=PlayerArray[PID].location + NumOfSpaces - 40;
        PlayerArray[PID].location=remain;
        return true;
    }
    else{
        return false;
    }
}

void player::PassedGO (int turnCount,int numSpaces){
    if(location + numSpaces > 39){
        location=(location + numSpaces) % 40;
        Bal +=200;

    }
    else{
        location += numSpaces;
        return;
    }
}
void MainWindow::MovePlayer(int PID, int numSpaces){

    QLabel* player = getPlayerLabel(PID);

    int x = player->x();
    int y = player->y();
    //PlayerArray[turnCount].PassedGO(turnCount,numSpaces);

    update_Summary();
    QSequentialAnimationGroup *totalMovement = new QSequentialAnimationGroup(player);


    QPropertyAnimation *moveLeft = new QPropertyAnimation(player, "geometry");
    QPropertyAnimation *moveUp = new QPropertyAnimation(player, "geometry");
    QPropertyAnimation *moveRight = new QPropertyAnimation(player, "geometry");
    QPropertyAnimation *moveDown = new QPropertyAnimation(player, "geometry");

    //----------------------------------------------------------------------------

    if(PID == 0){
        while(numSpaces > 0){
            if(x > 555 && y == 855){
                int startX = x;
                x = x - 75;
                moveLeft = new QPropertyAnimation(player, "geometry");
                moveLeft->setDuration(250);
                moveLeft->setStartValue(QRect(startX,y,28,28));
                moveLeft->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveLeft);
                numSpaces--;
            }
            else if(x == 555 && y > 125){
                int startY = y;
                y = y - 73;
                moveUp = new QPropertyAnimation(player, "geometry");
                moveUp->setDuration(250);
                moveUp->setStartValue(QRect(x,startY,28,28));
                moveUp->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveUp);
                numSpaces--;
            }
            else if(x < 1305 && y == 125){
                int startX = x;
                x = x + 75;
                moveRight = new QPropertyAnimation(player, "geometry");
                moveRight->setDuration(250);
                moveRight->setStartValue(QRect(startX,y,28,28));
                moveRight->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveRight);
                numSpaces--;
            }
            else if(x == 1305 && y < 855){
                int startY = y;
                y = y + 73;
                moveDown = new QPropertyAnimation(player, "geometry");
                moveDown->setDuration(250);
                moveDown->setStartValue(QRect(x,startY,28,28));
                moveDown->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveDown);
                numSpaces--;

            }
        }
        }

        //----------------------------------------------------------------------------------

        if(PID == 1){
        while(numSpaces > 0){
            if(x > 590 && y == 855){
                int startX = x;
                x = x - 75;
                moveLeft = new QPropertyAnimation(player, "geometry");
                moveLeft->setDuration(250);
                moveLeft->setStartValue(QRect(startX,y,28,28));
                moveLeft->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveLeft);
                numSpaces--;
            }
            else if(x == 590 && y > 125){
                int startY = y;
                y = y - 73;
                moveUp = new QPropertyAnimation(player, "geometry");
                moveUp->setDuration(250);
                moveUp->setStartValue(QRect(x,startY,28,28));
                moveUp->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveUp);
                numSpaces--;
            }
            else if(x < 1340 && y == 125){
                int startX = x;
                x = x + 75;
                moveRight = new QPropertyAnimation(player, "geometry");
                moveRight->setDuration(250);
                moveRight->setStartValue(QRect(startX,y,28,28));
                moveRight->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveRight);
                numSpaces--;
            }
            else if(x == 1340 && y < 855){
                int startY = y;
                y = y + 73;
                moveDown = new QPropertyAnimation(player, "geometry");
                moveDown->setDuration(250);
                moveDown->setStartValue(QRect(x,startY,28,28));
                moveDown->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveDown);
                numSpaces--;

            }
        }
        }

        //----------------------------------------------------------------------------------

        if(PID == 2){
        while(numSpaces > 0){
            if(x > 555 && y == 890){
                int startX = x;
                x = x - 75;
                moveLeft = new QPropertyAnimation(player, "geometry");
                moveLeft->setDuration(250);
                moveLeft->setStartValue(QRect(startX,y,28,28));
                moveLeft->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveLeft);
                numSpaces--;
            }
            else if(x == 555 && y > 160){
                int startY = y;
                y = y - 73;
                moveUp = new QPropertyAnimation(player, "geometry");
                moveUp->setDuration(250);
                moveUp->setStartValue(QRect(x,startY,28,28));
                moveUp->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveUp);
                numSpaces--;
            }
            else if(x < 1305 && y == 160){
                int startX = x;
                x = x + 75;
                moveRight = new QPropertyAnimation(player, "geometry");
                moveRight->setDuration(250);
                moveRight->setStartValue(QRect(startX,y,28,28));
                moveRight->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveRight);
                numSpaces--;
            }
            else if(x == 1305 && y < 890){
                int startY = y;
                y = y + 73;
                moveDown = new QPropertyAnimation(player, "geometry");
                moveDown->setDuration(250);
                moveDown->setStartValue(QRect(x,startY,28,28));
                moveDown->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveDown);
                numSpaces--;

            }
        }
        }

        //----------------------------------------------------------------------------------

        if(PID == 3){
        while(numSpaces > 0){
            if(x > 590 && y == 890){
                int startX = x;
                x = x - 75;
                moveLeft = new QPropertyAnimation(player, "geometry");
                moveLeft->setDuration(250);
                moveLeft->setStartValue(QRect(startX,y,28,28));
                moveLeft->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveLeft);
                numSpaces--;
            }
            else if(x == 590 && y > 160){
                int startY = y;
                y = y - 73;
                moveUp = new QPropertyAnimation(player, "geometry");
                moveUp->setDuration(250);
                moveUp->setStartValue(QRect(x,startY,28,28));
                moveUp->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveUp);
                numSpaces--;
            }
            else if(x < 1340 && y == 160){
                int startX = x;
                x = x + 75;
                moveRight = new QPropertyAnimation(player, "geometry");
                moveRight->setDuration(250);
                moveRight->setStartValue(QRect(startX,y,28,28));
                moveRight->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveRight);
                numSpaces--;
            }
            else if(x == 1340 && y < 890){
                int startY = y;
                y = y + 73;
                moveDown = new QPropertyAnimation(player, "geometry");
                moveDown->setDuration(250);
                moveDown->setStartValue(QRect(x,startY,28,28));
                moveDown->setEndValue(QRect(x,y,28,28));
                totalMovement->addAnimation(moveDown);
                numSpaces--;

            }
        }
        }
    //event();
    totalMovement->start();
    //totalMovement->finished();



    /*
    delete totalMovement;
    delete moveDown;
    delete moveUp;
    delete moveRight;
    delete moveLeft;
    */
}


void MainWindow::Continue_Game(){
     ui->SummaryBox->append("Summary Of Player Data Collected : \n");
     for(int i =0;i<playerNum;i++){
        std::string temp = PlayerArray[i].PlayerName;
        ui->SummaryBox->append(QString::fromStdString(temp));
        std::string temp1 = std::to_string(PlayerArray[i].PID);
        ui->SummaryBox->append(QString::fromStdString(temp1));
        std::string temp2 = std::to_string(PlayerArray[i].Bal);
        ui->SummaryBox->append(QString::fromStdString(temp2));
        std::string temp3 = std::to_string(PlayerArray[i].location);
        ui->SummaryBox->append(QString::fromStdString(temp3));

     }
     //PlayerArray[0].location=19;

     RollDicePrompt();


}

void MainWindow::update_Summary(){
    ui->SummaryBox->setText("");
    ui->player1Box->setText("");
    for(int i =0;i<playerNum;i++){
       std::string temp ="Name : " +PlayerArray[i].PlayerName;
       ui->SummaryBox->append(QString::fromStdString(temp));
       std::string temp1 ="ID : " + std::to_string(PlayerArray[i].PID);
       ui->SummaryBox->append(QString::fromStdString(temp1));
       std::string temp2 = "Balance : "+ std::to_string(PlayerArray[i].Bal);
       ui->SummaryBox->append(QString::fromStdString(temp2));
       std::string temp3 = "Location# : "+std::to_string(PlayerArray[i].location);
       ui->SummaryBox->append(QString::fromStdString(temp3));

    }
    ui->player1Box->setText(QString::fromStdString(PlayerArray[0].PlayerName + " : " + std::to_string(PlayerArray[0].Bal)));
    ui->player2Box->setText(QString::fromStdString(PlayerArray[1].PlayerName + " : " + std::to_string(PlayerArray[1].Bal)));
    ui->player3Box->setText(QString::fromStdString(PlayerArray[2].PlayerName + " : " + std::to_string(PlayerArray[2].Bal)));
    ui->player4Box->setText(QString::fromStdString(PlayerArray[3].PlayerName + " : " + std::to_string(PlayerArray[3].Bal)));
}



void MainWindow::Set_Player_Num(){
    //shit
    playerNum=std::stoi(input); //but when code gets here it just crashes. string to int.
    //playerNum=std::stoi("44");//thats not the point of the command.
    player_num_done=true;
}

int MainWindow::get_Max(int roll1, int roll2,int roll3,int roll4){

    /*
    int max=roll1;
    int array[4]={roll1,roll2,roll3,roll4};
    for(int i =0; i <4; i++){
        if(max < array[i]){
            max=array[i];
        }
    }
    //std::sort(array,array + 4);
    PlayerArray[]*/
    return 1;
}
void MainWindow::on_ContinueButton_clicked()
{
    //ooooooooooooooooo i got it am dumb yes
    /*
    if(FirstRoll){
        bool done=false;
        int roll11,roll22,roll33,roll44;
            roll11 = (rand() % (6 - 1 + 1) + 1) +  (rand() % (6 - 1 + 1) + 1);
            roll22 = rand() % (6 - 1 + 1) + 1 +  (rand() % (6 - 1 + 1) + 1);
            roll33= rand() % (6 - 1 + 1) + 1 +  (rand() % (6 - 1 + 1) + 1);
            roll44= rand() % (6 - 1 + 1) + 1 +  (rand() % (6 - 1 + 1) + 1);
            int max= get_Max(roll11,roll22,roll33,roll44);

        FirstRoll=false;
    }*/
    FirstRoll=false;
    Copy_Input();

    if(!player_num_done){
        Set_Player_Num();
    }
    if(!player_name_done){
        Set_Player_Names();
        infoCount++;
    }
    if(Roll_Dice){
        RollDice();
    }
    if(player_num_done && player_name_done){
        return;
    }
}
location::location(){
    int yes=1;
}
player::player(){
    //yes
    //PlayerName=;
         DiceRoll = 0;
         Bal=1500;
         location=0;
         TiedRoll = true; // bool to help determine first turn - if two players have the same dice roll before game this will be set to true
         InJail = false; // bool to see if player is in jail
         JailTurns = 0; // number of turns in jail
         GOOJF = false; // GET OUT OF JAIL FREE CARD
         DoublesCount = 0; // TO CHECK IF PLAYER HAS ROLLED 3 DOUBLES IN A ROW
         Bankrupt = false;
         Bot = false;

    }



void MainWindow::RollDicePrompt() {
    ui->BuyButton->setVisible(false);
    ui->SkipButton->setVisible(false);

    if(FirstRoll){
        bool done=false;
        std::string oline = "Roll to see who goes first. (Click Continue)";
        ui->textConsole->append(QString::fromStdString(oline));
    }

    if(PlayerArray[turnCount].Doubles && PlayerArray[turnCount].DoublesCount==3){
        std::string oline = PlayerArray[turnCount].PlayerName + " Rolled 3 doubles, You're going in the slammer\n";
        ui->textConsole->append(QString::fromStdString(oline));
        num_till_destSquares = Squares_to_target(10);
        PlayerArray[turnCount].InJail=true;
        PlayerArray[turnCount].Doubles=false;
        MovePlayer(turnCount,num_till_destSquares);

    }
    if(PlayerArray[turnCount].InJail){
        ui->textConsole->append("Roll Doubles to get out of jail");
        RollDice();
    }
    if(PlayerArray[turnCount].Doubles==false){
        if (turnCount ==3){
            turnCount=0;
        }
        else{
            turnCount++;
        }
    }

    if (PlayerArray[turnCount].firstTime==false){
       std::string line = "\n" + PlayerArray[turnCount].PlayerName + " is on " + BoardVec[PlayerArray[turnCount].location].Name + "\n";
       ui->textConsole->setText(QString::fromStdString(line));
    }
    std::string inplace; // JUST A TEMP STRING TO ALLOW FOR CIN TO ADD ACTION TO DICE ROLL
    int min = 1;
    int max = 6;
    if (!PlayerArray[turnCount].Bot) {
        std::string oline = PlayerArray[turnCount].PlayerName + " press 'Continue' to roll the dice\n";
        ui->textConsole->append(QString::fromStdString(oline));
        Roll_Dice=true;
        PlayerArray[turnCount].firstTime=true;

    }

}

void MainWindow::RollDice(){

    QString s1="D:\\Users\\MightyTidy\\Documents\\SeniorSem2\\SenSem\\MonopolyProject\\Other Game\\Dice\\dice1.png";
    QPixmap dice1=s1;
    QString s2="D:\\Users\\MightyTidy\\Documents\\SeniorSem2\\SenSem\\MonopolyProject\\Other Game\\Dice\\dice2.png";
    QPixmap dice2=s2;
    QString s3="D:\\Users\\MightyTidy\\Documents\\SeniorSem2\\SenSem\\MonopolyProject\\Other Game\\Dice\\dice3.png";
    QPixmap dice3=s3;
    QString s4="D:\\Users\\MightyTidy\\Documents\\SeniorSem2\\SenSem\\MonopolyProject\\Other Game\\Dice\\dice4.png";
    QPixmap dice4=s4;
    QString s5="D:\\Users\\MightyTidy\\Documents\\SeniorSem2\\SenSem\\MonopolyProject\\Other Game\\Dice\\dice5.png";
    QPixmap dice5=s5;
    QString s6="D:\\Users\\MightyTidy\\Documents\\SeniorSem2\\SenSem\\MonopolyProject\\Other Game\\Dice\\dice6.png";
    QPixmap dice6=s6;

    int roll1 = 0, roll2 = 0, roll = 0;
    roll1 = rand() % (6 - 1 + 1) + 1;
    roll2 = rand() % (6 - 1 + 1) + 1;
    roll = roll1 + roll2;
    roll=7;
    turnRoll=roll;
    std::string line = PlayerArray[turnCount].PlayerName + " rolled " + std::to_string(roll1) +" on the first dice and  "+std::to_string(roll2) +" on the second dice" ;
    ui->textConsole->setText(QString::fromStdString(line));
    if(roll1 == roll2){
        std::string line = "\n" + PlayerArray[turnCount].PlayerName + "Rolled Doubles, you'll get another turn!";
        ui->textConsole->append(QString::fromStdString(line));
        PlayerArray[turnCount].Doubles=true;
        PlayerArray[turnCount].DoublesCount++;
        if(PlayerArray[turnCount].InJail==true){
           ui->textConsole->append("You've rolled doubles and got out of jail");
           PlayerArray[turnCount].InJail=false;
        }

    }
    else{
        PlayerArray[turnCount].Doubles=false;
        PlayerArray[turnCount].DoublesCount=0;
    }
    if(roll1==1){
        ui->dice1->setPixmap(dice1);
    }
    if(roll1==2){
        ui->dice1->setPixmap(dice2);
    }
    if(roll1==3){
        ui->dice1->setPixmap(dice3);
    }
    if(roll1==4){
        ui->dice1->setPixmap(dice4);
    }
    if(roll1==5){
        ui->dice1->setPixmap(dice5);
    }
    if(roll1==6){
        ui->dice1->setPixmap(dice6);
    }


    if(roll2==1){
        ui->dice2->setPixmap(dice1);
    }
    if(roll2==2){
        ui->dice2->setPixmap(dice2);
    }
    if(roll2==3){
        ui->dice2->setPixmap(dice3);
    }
    if(roll2==4){
        ui->dice2->setPixmap(dice4);
    }
    if(roll2==5){
        ui->dice2->setPixmap(dice5);
    }
    if(roll2==6){
        ui->dice2->setPixmap(dice6);
    }


    PlayerArray[turnCount].DiceRoll = roll;
        bool GotDubs = false;
        /*
        if (!FirstRoll) {
            if (roll1 == roll2) { // IF PLAYER IS IN JAIL AND ROLLS DOUBLES, GETS OUT OF JAIL
                GotDubs = true;
                if (PlayerArray[turnCount].InJail) {
                    std::string aline = "Doubles set you free\n";
                    ui->textConsole->append(QString::fromStdString(aline));
                    PlayerArray[turnCount].InJail = false;
                    PlayerArray[turnCount].JailTurns = 0;
                    PlayerArray[turnCount].DiceRoll = roll;
                    PlayerArray[turnCount].DoublesCount++;
                    MovePlayer(turnCount,roll);//move player here
                }
                else {
                    PlayerArray[turnCount].DiceRoll = roll;
                    PlayerArray[turnCount].DoublesCount++;
                    MovePlayer(turnCount,roll);

                }
            }
            if (!GotDubs && !PlayerArray[turnCount].InJail) {
                MovePlayer(turnCount,roll);// move places on the board
            }
        }
        */

        Roll_Dice=false;

        //MovePlayer(turnCount,roll);

        PlayerArray[turnCount].PassedGO(turnCount,roll);



        if(PlayerArray[turnCount].location == 7 || PlayerArray[turnCount].location == 22 || PlayerArray[turnCount].location == 36 ){
            //QThread::sleep(3); //we should get rid of this and add event handler on playerlabel too see if animation is done.
            ChanceCard();


             RollDicePrompt();
        }
        else{
            MovePlayer(turnCount,roll);
            BuyPrompt();
            //RollDicePrompt(false);
        }

    }


void MainWindow::CheckJail(){
     if(!BoardVec[PlayerArray[turnCount].location].Owned && !BoardVec[PlayerArray[turnCount].location].isProperty){
            if(PlayerArray[turnCount].location==10){
                if(!PlayerArray[turnCount].InJail){
                     ui->textConsole->append("Just Visiting.");
                     RollDicePrompt();
                }
                else{
                    ui->textConsole->append("Locked Up.");
                    RollDicePrompt();
                }
            }
            else{
                RollDicePrompt();
            }
            if(PlayerArray[turnCount].location==30){
                ui->textConsole->append("You're goin in the slamma.");
                PlayerArray[turnCount].Doubles=false;
                PlayerArray[turnCount].InJail=true;
                MovePlayer(turnCount,20);

            }




        }
}


void MainWindow::BuyPrompt(){
    std::string buyprompt= PlayerArray[turnCount].PlayerName +" has landed on "+ BoardVec[PlayerArray[turnCount].location].Name;
    ui->textConsole->append(QString::fromStdString(buyprompt));
    int rent=0;
    CheckJail();
    if(BoardVec[PlayerArray[turnCount].location].Owned){
        int ownerID=BoardVec[PlayerArray[turnCount].location].OwnerID ;
        std::string placeOwner=PlayerArray[ownerID].PlayerName;
        ui->textConsole->append(QString::fromStdString(placeOwner +" owns this location, Pay Rent. "));

        if(BoardVec[PlayerArray[turnCount].location].isUtility){
            if(PlayerArray[turnCount].location==12){
                if(BoardVec[PlayerArray[turnCount].location].OwnerID ==BoardVec[28].OwnerID){
                    rent = 10 * turnRoll;
                    //PlayerArray[turnCount].Bal-=rent;

                }
            }
            else{
                rent = 4 * turnRoll;
                //PlayerArray[turnCount].Bal-=rent;
            }
            ui->textConsole->append(QString::fromStdString("Taking "+ std::to_string(rent) + "$ from Balance..." ));
            payPlayer(PlayerArray[turnCount].location,rent);

        }
        else{
            ui->textConsole->append(QString::fromStdString("Taking "+ std::to_string(BoardVec[PlayerArray[turnCount].location].Rent) + "$ from Balance..." ));
            //PlayerArray[turnCount].Bal-=BoardVec[PlayerArray[turnCount].location].Rent;
            payPlayer(PlayerArray[turnCount].location,0);
            update_Summary();
            RollDicePrompt();

        }


    }
    else if(!BoardVec[PlayerArray[turnCount].location].Owned && BoardVec[PlayerArray[turnCount].location].isProperty){
        ui->ContinueButton->setVisible(false);
        std::string buyprompt= "GOT TO HERE Would you like to buy it?\nYour current budget is : "+std::to_string(PlayerArray[turnCount].Bal);
        ui->textConsole->append(QString::fromStdString(buyprompt));
        ui->BuyButton->setVisible(true);
        ui->SkipButton->setVisible(true);

    }






}
void MainWindow::on_BuyButton_clicked(){
    ui->ContinueButton->setVisible(true);
    if(BoardVec[PlayerArray[turnCount].location].Owned || !BoardVec[PlayerArray[turnCount].location].isProperty){
        ui->textConsole->setText("You can't buy this property!");
        ui->textConsole->append("What are you a QA tester???");
    }
    else{
        ui->textConsole->setText(QString::fromStdString("You Bought: " + BoardVec[PlayerArray[turnCount].location].Name));
        BoardVec[PlayerArray[turnCount].location].Owned=true;
        BoardVec[PlayerArray[turnCount].location].OwnerID=turnCount;
        ui->textConsole->append(QString::fromStdString("Taking "+ std::to_string(BoardVec[PlayerArray[turnCount].location].Price) + "$ from Balance..." ));
        PlayerArray[turnCount].Bal-=BoardVec[PlayerArray[turnCount].location].Price;
        update_Summary();
    }


    RollDicePrompt();

}
void MainWindow::foldUI(){
    ui->InputBox1->clear();
    ui->InputBox1->setVisible(false);
    ui->textConsole->setFixedHeight(361);
    ui->BuyButton->move(820,600); // was 770x and 390y
    ui->SkipButton->move(1000,600); // was 1050x and 390y
    ui->BuyButton->setVisible(true);
    ui->SkipButton->setVisible(true);
}
void MainWindow::Set_Player_Names(){
        ui->textConsole->setText("Enter the player names in the box below seperated by a comma");
        Copy_Input();
        std::stringstream s(input);
        std::string nameList;
        std::string nameA;
        std::string nameB;
        std::string nameC;
        std::string nameD;

        std::vector <std::string> words;
        int count =0,count1=0;
        ui->PlayersText->setText("");
        if(infoCount==1){
        if(playerNum==4){
            for(int i=0; i<playerNum;i++){
                player obj;
                PlayerArray.push_back(obj);
                PlayerArray[i].PID=i;
            }
        }
        if(playerNum < 4){
            for(int i=0; i<playerNum;i++){ //-1 because 4 players is array[3]
                count1++;
                player obj;
                PlayerArray.push_back(obj);
                PlayerArray[i].PID=i;
            }
            for(int i=count1; i<4;i++){
                player objBot;
                PlayerArray.push_back(objBot);
                PlayerArray[i].PID=i;
                PlayerArray[i].Bot=true;
            }
        }
        player_name_done=true;
        foldUI();

        player Bank;
        Bank.PlayerName = "Bank";
        Bank.PID = 5;
        PlayerArray.push_back(Bank);
        while(std::getline(s, input, ',')) {
             PlayerArray[count].PlayerName=input;
             ui->PlayersText->append(QString::fromStdString(input));
             count++;
        }
        location Board[40]; // ARRAY OF LOCATION OBJECTS REPRESENTING THE BOARD


            // NON-PROPERTY TILES
            // CORNER TILES
        location GO;
                   GO.isProperty = false;
                   GO.Name = "GO";
                   Board[0] = GO;

                   location JAIL;
                   JAIL.isProperty = false;
                   JAIL.Name = "JAIL";
                   Board[10] = JAIL;

                   location FREEPARKING;
                   FREEPARKING.isProperty = false;
                   FREEPARKING.Name = "FREEPARKING";
                   Board[20] = FREEPARKING;

                   location GOTOJAIL;
                   GOTOJAIL.isProperty = false;
                   GOTOJAIL.Name = "GOTOJAIL";
                   Board[30] = GOTOJAIL;

               //------------------------------------------------------------------------------------------------------------------
                   // IN-BOARD TILES
                   location CommunityChest;
                   CommunityChest.isProperty = false;
                   CommunityChest.Name = "CommunityChest";
                   Board[2] = CommunityChest;
                   Board[17] = CommunityChest;
                   Board[33] = CommunityChest;

                   location Chance;
                   Chance.isProperty = false;
                   Chance.Name = "Chance";
                   Board[7] = Chance;
                   Board[22] = Chance;
                   Board[36] = Chance;

                   location IncomeTax; // not a property, but acts as a property owned by the bank collecting rent
                   IncomeTax.Name = "IncomeTax";
                   IncomeTax.isProperty = false;
                   IncomeTax.Rent = 200;
                   IncomeTax.Owned = true; // rent tiles are "owned" so they can be deducted as rent easily
                   IncomeTax.OwnerID = 4; // ownerID 5 is the bank, going to have function Pay to deduct/add to and from player accounts
                   Board[4] = IncomeTax;


                   location LuxuryTax;
                   LuxuryTax.Name = "LuxuryTax";
                   LuxuryTax.isProperty = false;
                   LuxuryTax.Rent = 75;
                   LuxuryTax.Owned = true;
                   LuxuryTax.OwnerID = 4;
                   Board[38] = LuxuryTax;


                   //----------------------------------------------------------------------------------------------------------------------
                   // PROPERTY TILES
                   location Meadows;
                   Meadows.Name = "Meadows";
                   Meadows.Price = 60;
                   Meadows.Rent = 2;
                   Meadows.Rent1H = 10;
                   Meadows.Rent2H = 30;
                   Meadows.Rent3H = 90;
                   Meadows.Rent4H = 160;
                   Meadows.RentH = 250;
                   Meadows.MortgageVal = 30;
                   Meadows.HouseP = 50;
                   Meadows.Color = "Purple";
                   Board[1] = Meadows;

                   location Pine;
                   Pine.Name = "Pine";
                   Pine.Price = 60;
                   Pine.Rent = 4;
                   Pine.Rent1H = 20;
                   Pine.Rent2H = 60;
                   Pine.Rent3H = 180;
                   Pine.Rent4H = 320;
                   Pine.RentH = 450;
                   Pine.MortgageVal = 30;
                   Pine.HouseP = 50;
                   Pine.Color = "Purple";
                   Board[3] = Pine;

                   location Chase;
                   Chase.Name = "Chase";
                   Chase.Price = 200;
                   Chase.isRailroad = true;
                   Chase.Rent = 25;
                   Chase.Rent1H = 25;
                   Chase.Rent2H = 50;
                   Chase.Rent3H = 100;
                   Chase.Rent4H = 200;
                   Chase.MortgageVal = 100;
                   Board[5] = Chase;

                   location Young;
                   Young.Name = "Young";
                   Young.Price = 100;
                   Young.Rent = 6;
                   Young.Rent1H = 30;
                   Young.Rent2H = 90;
                   Young.Rent3H = 270;
                   Young.Rent4H = 400;
                   Young.RentH = 550;
                   Young.HouseP = 50;
                   Young.MortgageVal = 50;
                   Young.Color = "LightBlue";
                   Board[6] = Young;

                   location Mcintire;
                   Mcintire.Name = "Mcintire";
                   Mcintire.Price = 100;
                   Mcintire.Rent = 6;
                   Mcintire.Rent1H = 30;
                   Mcintire.Rent2H = 90;
                   Mcintire.Rent3H = 270;
                   Mcintire.Rent4H = 400;
                   Mcintire.RentH = 550;
                   Mcintire.HouseP = 50;
                   Mcintire.MortgageVal = 50;
                   Mcintire.Color = "LightBlue";
                   Board[8] = Mcintire;

                   location Clark;
                   Clark.Name = "Clark";
                   Clark.Price = 120;
                   Clark.Rent = 8;
                   Clark.Rent1H = 40;
                   Clark.Rent2H = 100;
                   Clark.Rent3H = 300;
                   Clark.Rent4H = 450;
                   Clark.RentH = 600;
                   Clark.MortgageVal = 60;
                   Clark.HouseP = 50;
                   Clark.Color = "LightBlue";
                   Board[9] = Clark;

                   location Knapton;
                   Knapton.Name = "Knapton";
                   Knapton.Price = 140;
                   Knapton.Rent = 10;
                   Knapton.Rent1H = 50;
                   Knapton.Rent2H = 150;
                   Knapton.Rent3H = 450;
                   Knapton.Rent4H = 625;
                   Knapton.RentH = 750;
                   Knapton.MortgageVal = 70;
                   Knapton.HouseP = 100;
                   Knapton.Color = "Pink";
                   Board[11] = Knapton;

                   location ArtHouse;
                   ArtHouse.Name = "ArtHouse";
                   ArtHouse.isUtility = true; // utilities accumulate rent through multiplying the dice roll
                   ArtHouse.Price = 150;
                   ArtHouse.MortgageVal = 75;
                   Board[12] = ArtHouse;

                   location Meneely;
                   Meneely.Name = "Meneely";
                   Meneely.Price = 140;
                   Meneely.Rent = 10;
                   Meneely.Rent1H = 50;
                   Meneely.Rent2H = 150;
                   Meneely.Rent3H = 450;
                   Meneely.Rent4H = 625;
                   Meneely.RentH = 750;
                   Meneely.MortgageVal = 70;
                   Meneely.HouseP = 100;
                   Meneely.Color = "Pink";
                   Board[13] = Meneely;

                   location Watson;
                   Watson.Name = "Watson";
                   Watson.Price = 160;
                   Watson.Rent = 12;
                   Watson.Rent1H = 60;
                   Watson.Rent2H = 180;
                   Watson.Rent3H = 500;
                   Watson.Rent4H = 700;
                   Watson.RentH = 900;
                   Watson.MortgageVal = 80;
                   Watson.HouseP = 100;
                   Watson.Color = "Pink";
                   Board[14] = Watson;

                   location SpencerDavisCafe;
                   SpencerDavisCafe.Name = "SpencerDavisCafe";
                   SpencerDavisCafe.Price = 200;
                   SpencerDavisCafe.isRailroad = true;
                   SpencerDavisCafe.Rent = 25;
                   SpencerDavisCafe.Rent1H = 25;
                   SpencerDavisCafe.Rent2H = 50;
                   SpencerDavisCafe.Rent3H = 100;
                   SpencerDavisCafe.Rent4H = 200;
                   SpencerDavisCafe.MortgageVal = 100;
                   Board[15] = SpencerDavisCafe;

                   location ScienceCenter;
                   ScienceCenter.Name = "ScienceCenter";
                   ScienceCenter.Price = 180;
                   ScienceCenter.Rent = 14;
                   ScienceCenter.Rent1H = 70;
                   ScienceCenter.Rent2H = 200;
                   ScienceCenter.Rent3H = 550;
                   ScienceCenter.Rent4H = 750;
                   ScienceCenter.RentH = 950;
                   ScienceCenter.MortgageVal = 90;
                   ScienceCenter.HouseP = 100;
                   ScienceCenter.Color = "Orange";
                   Board[16] = ScienceCenter;

                   location LockSmith;
                   LockSmith.Name = "LockSmith";
                   LockSmith.Price = 180;
                   LockSmith.Rent = 14;
                   LockSmith.Rent1H = 70;
                   LockSmith.Rent2H = 200;
                   LockSmith.Rent3H = 550;
                   LockSmith.Rent4H = 750;
                   LockSmith.RentH = 950;
                   LockSmith.MortgageVal = 90;
                   LockSmith.HouseP = 100;
                   LockSmith.Color = "Orange";
                   Board[18] = LockSmith;

                   location Balfour;
                   Balfour.Name = "Balfour";
                   Balfour.Price = 200;
                   Balfour.Rent = 16;
                   Balfour.Rent1H = 80;
                   Balfour.Rent2H = 220;
                   Balfour.Rent3H = 600;
                   Balfour.Rent4H = 800;
                   Balfour.RentH = 1000;
                   Balfour.MortgageVal = 100;
                   Balfour.HouseP = 100;
                   Balfour.Color = "Orange";
                   Board[19] = Balfour;

                   location Gebbie;
                   Gebbie.Name = "Gebbie";
                   Gebbie.Price = 220;
                   Gebbie.Rent = 18;
                   Gebbie.Rent1H = 90;
                   Gebbie.Rent2H = 250;
                   Gebbie.Rent3H = 700;
                   Gebbie.Rent4H = 875;
                   Gebbie.RentH = 1050;
                   Gebbie.MortgageVal = 110;
                   Gebbie.HouseP = 150;
                   Gebbie.Color = "Red";
                   Board[21] = Gebbie;

                   location Keefe;
                   Keefe.Name = "Keefe";
                   Keefe.Price = 220;
                   Keefe.Rent = 18;
                   Keefe.Rent1H = 90;
                   Keefe.Rent2H = 250;
                   Keefe.Rent3H = 700;
                   Keefe.Rent4H = 875;
                   Keefe.RentH = 1050;
                   Keefe.MortgageVal = 110;
                   Keefe.HouseP = 150;
                   Keefe.Color = "Red";
                   Board[23] = Keefe;

                   location Beard;
                   Beard.Name = "Beard";
                   Beard.Price = 240;
                   Beard.Rent = 20;
                   Beard.Rent1H = 100;
                   Beard.Rent2H = 300;
                   Beard.Rent3H = 750;
                   Beard.Rent4H = 925;
                   Beard.RentH = 1100;
                   Beard.MortgageVal = 120;
                   Beard.HouseP = 150;
                   Beard.Color = "Red";
                   Board[24] = Beard;

                   location Emerson;
                   Emerson.Name = "Emerson";
                   Emerson.Price = 200;
                   Emerson.isRailroad = true;
                   Emerson.Rent = 25;
                   Emerson.Rent1H = 25; // in this case 1 house refers to 1 owned railroad
                   Emerson.Rent2H = 50;
                   Emerson.Rent3H = 100;
                   Emerson.Rent4H = 200;
                   Emerson.MortgageVal = 100;
                   Board[25] = Emerson;

                   location Firepit;
                   Firepit.Name = "Firepit";
                   Firepit.Price = 260;
                   Firepit.Rent = 22;
                   Firepit.Rent1H = 110;
                   Firepit.Rent2H = 330;
                   Firepit.Rent3H = 800;
                   Firepit.Rent4H = 975;
                   Firepit.RentH = 1150;
                   Firepit.MortgageVal = 130;
                   Firepit.HouseP = 150;
                   Firepit.Color = "Yellow";
                   Board[26] = Firepit;

                   location RedRock;
                   RedRock.Name = "RedRock";
                   RedRock.Price = 260;
                   RedRock.Rent = 22;
                   RedRock.Rent1H = 110;
                   RedRock.Rent2H = 330;
                   RedRock.Rent3H = 800;
                   RedRock.Rent4H = 975;
                   RedRock.RentH = 1150;
                   RedRock.MortgageVal = 130;
                   RedRock.HouseP = 150;
                   RedRock.Color = "Yellow";
                   Board[27] = RedRock;

                   location MADHouse;
                   MADHouse.Name = "MADHouse";
                   MADHouse.isUtility = true; // utilities accumulate rent through multiplying the dice roll
                   MADHouse.Price = 150;
                   MADHouse.MortgageVal = 75;
                   Board[28] = MADHouse;

                   location WitchesHut;
                   WitchesHut.Name = "WitchesHut";
                   WitchesHut.Price = 280;
                   WitchesHut.Rent = 24;
                   WitchesHut.Rent1H = 120;
                   WitchesHut.Rent2H = 360;
                   WitchesHut.Rent3H = 850;
                   WitchesHut.Rent4H = 1025;
                   WitchesHut.RentH = 1200;
                   WitchesHut.MortgageVal = 140;
                   WitchesHut.HouseP = 150;
                   WitchesHut.Color = "Yellow";
                   Board[29] = WitchesHut;

                   location ParkHall;
                   ParkHall.Name = "ParkHall";
                   ParkHall.Price = 300;
                   ParkHall.Rent = 26;
                   ParkHall.Rent1H = 130;
                   ParkHall.Rent2H = 390;
                   ParkHall.Rent3H = 900;
                   ParkHall.Rent4H = 1100;
                   ParkHall.RentH = 1275;
                   ParkHall.MortgageVal = 150;
                   ParkHall.HouseP = 200;
                   ParkHall.Color = "Green";
                   Board[31] = ParkHall;

                   location MaryLyon;
                   MaryLyon.Name = "MaryLyon";
                   MaryLyon.Price = 300;
                   MaryLyon.Rent = 26;
                   MaryLyon.Rent1H = 130;
                   MaryLyon.Rent2H = 390;
                   MaryLyon.Rent3H = 900;
                   MaryLyon.Rent4H = 1100;
                   MaryLyon.RentH = 1275;
                   MaryLyon.MortgageVal = 150;
                   MaryLyon.HouseP = 200;
                   MaryLyon.Color = "Green";
                   Board[32] = MaryLyon;

                   location Chapel;
                   Chapel.Name = "Chapel";
                   Chapel.Price = 320;
                   Chapel.Rent = 28;
                   Chapel.Rent1H = 150;
                   Chapel.Rent2H = 450;
                   Chapel.Rent3H = 1000;
                   Chapel.Rent4H = 1200;
                   Chapel.RentH = 1400;
                   Chapel.MortgageVal = 160;
                   Chapel.HouseP = 200;
                   Chapel.Color = "Green";
                   Board[34] = Chapel;

                   location HoodCafe;
                   HoodCafe.Name = "HoodCafe";
                   HoodCafe.Price = 200;
                   HoodCafe.isRailroad = true;
                   HoodCafe.Rent = 25;
                   HoodCafe.Rent1H = 25; // in this case 1 house refers to 1 owned railroad
                   HoodCafe.Rent2H = 50;
                   HoodCafe.Rent3H = 100;
                   HoodCafe.Rent4H = 200;
                   HoodCafe.MortgageVal = 100;
                   Board[35] = HoodCafe;

                   location PeacockPond;
                   PeacockPond.Name = "PeacockPond";
                   PeacockPond.Price = 350;
                   PeacockPond.Rent = 35;
                   PeacockPond.Rent1H = 175;
                   PeacockPond.Rent2H = 500;
                   PeacockPond.Rent3H = 1100;
                   PeacockPond.Rent4H = 1200;
                   PeacockPond.RentH = 1500;
                   PeacockPond.MortgageVal = 175;
                   PeacockPond.HouseP = 200;
                   PeacockPond.Color = "DarkBlue";
                   Board[37] = PeacockPond;

                   location HannosHouse;
                   HannosHouse.Name = "HannosHouse";
                   HannosHouse.Price = 400;
                   HannosHouse.Rent = 40;
                   HannosHouse.Rent1H = 200;
                   HannosHouse.Rent2H = 600;
                   HannosHouse.Rent3H = 1400;
                   HannosHouse.Rent4H = 1700;
                   HannosHouse.RentH = 2000;
                   HannosHouse.MortgageVal = 200;
                   HannosHouse.HouseP = 200;
                   HannosHouse.Color = "DarkBlue";
                   Board[39] = HannosHouse;





            for(int i=0; i<40;i++){
                BoardVec.push_back(Board[i]);
                Boardptr=&BoardVec;
            }


        //THIS NEEDS TO BE THE LAST RETURN OF ALL THE CODE OR DATA DIPS
        Continue_Game();}



}
int MainWindow::GetDirection(int PID){
    return PlayerArray[PID].Direction;
}
void MainWindow::FindCoords(int PID,int numOfSquares){
    int direction = PlayerArray[PID].Direction;


        if(direction ==1){
            int x = ui->Player1Label->x();
            int y = ui->Player1Label->y();
            x = x - (40 * numOfSquares);
            coords.push_back(x);
            coords.push_back(y);
        }
        else if (direction ==2){
            int x = ui->Player1Label->x();
            int y = ui->Player1Label->y();
            y = y - (40 * numOfSquares);
            coords.push_back(x);
            coords.push_back(y);
        }
        else if(direction==3){
            int x = ui->Player1Label->x();
            int y = ui->Player1Label->y();
            x = x + (40 * numOfSquares);
            coords.push_back(x);
            coords.push_back(y);
        }
        else if (direction ==4){
            int x = ui->Player1Label->x();
            int y = ui->Player1Label->y();
            y = y +  (40 * numOfSquares);
            coords.push_back(x);
            coords.push_back(y);
        }
}

int MainWindow::Squares_to_target(int destlocation){
    int squares=0;
    if(destlocation > PlayerArray[turnCount].location ){
         squares = destlocation -  PlayerArray[turnCount].location;
    }
    else if (destlocation < PlayerArray[turnCount].location){
        squares= 40 + abs(PlayerArray[turnCount].location - destlocation);
    }

    return squares;
}

void MainWindow::ChanceCard(){
    ui->textConsole->append(  "Landed on Chance Card!\n");
    int ChanceRoll = rand() % (16 - 1 + 1) + 1;
    if (ChanceRoll == 1){ // MOVE TO GO
                      ui->textConsole->append(  "Move to GO!\n");
                      //PlayerArray[turnCount].location = 0;
                      num_till_destSquares=Squares_to_target(0);
                      MovePlayer(turnCount,num_till_destSquares + turnRoll);
                      alreadyMoved=true;
                      //PlayerArray[turnCount].location = 0;
                      //PlayerArray[turnCount].Bal = PlayerArray[turnCount].Bal + 200;
                      PlayerArray[turnCount].PassedGO(turnCount, num_till_destSquares);
                      update_Summary();
                     // PlayerArray[turnCount].PassedGO(PlayerArray, BoardVec, turnCount);
                  }
              if (ChanceRoll == 2){ // GO TO FIRST RAILROAD
                  ui->textConsole->append(  "Move to Chase!\n");
                  num_till_destSquares=Squares_to_target(5);
                  MovePlayer(turnCount,num_till_destSquares + turnRoll);
                  PlayerArray[turnCount].PassedGO(turnCount, num_till_destSquares);
                  update_Summary();
                  alreadyMoved=true;
                  if(BoardVec[5].Owned==false){
                      BuyPrompt();
                  }
                  if (PlayerArray[turnCount].location > 5){
                     // PlayerArray[turnCount].PassedGO(PlayerArray, BoardVec, turnCount);
                  }
                  PlayerArray[turnCount].location = 5;
                  if (BoardVec[PlayerArray[turnCount].location].Owned && BoardVec[PlayerArray[turnCount].location].OwnerID != turnCount){
                    //  PlayerArray[turnCount].PayRent(PlayerArray, BoardVec, turnCount);
                  }
                  else if (!BoardVec[PlayerArray[turnCount].location].Owned){
                      ui->textConsole->append("Chase is unowned!\n Press '1' to buy\nPress '8' for property info\nPress '0' to skip\n");
                      ui->textConsole->append( QString::fromStdString( "Current balance: $" + std::to_string(PlayerArray[turnCount].Bal) + "\n"));
                      ui->textConsole->append( QString::fromStdString( "Cost: $" + std::to_string(BoardVec[PlayerArray[turnCount].location].Price) +  "\n"));
                     // int BuyOrNo;
                     // cin >> BuyOrNo;

                      //while (BuyOrNo == 8){
                         // PlayerArray[turnCount].UtilRRDetails(BoardVec, PlayerArray[turnCount].location);
                        //  ui->textConsole->append(  "Press '1' to buy, '8' for property info, or '0' to skip: \n");
                        //  cin >> BuyOrNo;
                     // }
                      //if (BuyOrNo == 1){ // IF BUYING
                        //  if (PlayerArray[turnCount].Bal < BoardVec[PlayerArray[turnCount].location].Price){
                         //     ui->textConsole->append(  "You can't afford this property\n");
                        //  }
                        //  else{
                        //      PlayerArray[turnCount].BuyProperty(PlayerArray, BoardVec, turnCount);
                         // }
                      //}
                  }
              }
               if (ChanceRoll == 3){ // GO TO FIRST PINK
                  ui->textConsole->append(  "Move to Knapton!\n");
                  num_till_destSquares=Squares_to_target(11);
                  MovePlayer(turnCount,num_till_destSquares + turnRoll);
                  PlayerArray[turnCount].PassedGO(turnCount, num_till_destSquares);
                  update_Summary();
                  alreadyMoved=true;
                  if(BoardVec[11].Owned==false){
                      BuyPrompt();
                  }
                  if (PlayerArray[turnCount].location > 11){
                     // PlayerArray[turnCount].PassedGO(PlayerArray, BoardVec, turnCount);
                  }
                  PlayerArray[turnCount].location = 11;
                  if (BoardVec[PlayerArray[turnCount].location].Owned && BoardVec[PlayerArray[turnCount].location].OwnerID != turnCount){
                      //PlayerArray[turnCount].PayRent(PlayerArray, BoardVec, turnCount);
                  }
                  else if (!BoardVec[PlayerArray[turnCount].location].Owned){
                      ui->textConsole->append(  "Knapton is unowned!\nPress '1' to buy\nPress '8' for property info\nPress '0' to skip\n");
                      ui->textConsole->append( QString::fromStdString( "Current balance: $" + std::to_string(PlayerArray[turnCount].Bal) + "\n"));
                      ui->textConsole->append( QString::fromStdString( "Cost: $" + std::to_string(BoardVec[PlayerArray[turnCount].location].Price) +  "\n"));
                      int BuyOrNo;
                      //cin >> BuyOrNo;

                      while (BuyOrNo == 8){
                          //PlayerArray[turnCount].PropDetails(BoardVec, PlayerArray[turnCount].location);
                          ui->textConsole->append(  "Press '1' to buy, '8' for property info, or '0' to skip: \n");
                          //cin >> BuyOrNo;
                      }
                      if (BuyOrNo == 1){ // IF BUYING
                          if (PlayerArray[turnCount].Bal < BoardVec[PlayerArray[turnCount].location].Price){
                              ui->textConsole->append(  "You can't afford this property\n");
                          }
                          else{
                              //PlayerArray[turnCount].BuyProperty(PlayerArray, BoardVec, turnCount);
                          }
                      }
                  }
              }
              if (ChanceRoll == 4){ // GO TO DADDYS HOUSE
                  ui->textConsole->append(  "Move to Hanno's House!\n");

                  num_till_destSquares=Squares_to_target(39);
                  MovePlayer(turnCount,num_till_destSquares + turnRoll);
                  PlayerArray[turnCount].PassedGO(turnCount, num_till_destSquares);
                  update_Summary();
                  alreadyMoved=true;
                  if(BoardVec[39].Owned==false){
                      BuyPrompt();
                  }
                  else{
                      int yes=1;
                  }

                  //if (PlayerArray[turnCount].location > 39){
                      //PlayerArray[turnCount].PassedGO(PlayerArray, BoardVec, turnCount);
                 // }
                  //PlayerArray[turnCount].location = 39;
                  //if (BoardVec[PlayerArray[turnCount].location].Owned && BoardVec[PlayerArray[turnCount].location].OwnerID != turnCount){
                     // PlayerArray[turnCount].PayRent(PlayerArray, BoardVec, turnCount);
                 // }
                  //else if (!BoardVec[PlayerArray[turnCount].location].Owned){
                      //ui->textConsole->append(  "Hanno's House is unowned!\nPress '1' to buy\nPress '8' for property info\nPress '0' to skip\n");
                     // ui->textConsole->append( QString::fromStdString( "Current balance: $" + std::to_string(PlayerArray[turnCount].Bal) + "\n"));
                     // ui->textConsole->append( QString::fromStdString( "Cost: $" + std::to_string(BoardVec[PlayerArray[turnCount].location].Price) +  "\n"));
                      //int BuyOrNo;
                      //cin >> BuyOrNo;

                      //while (BuyOrNo == 8){
                          //PlayerArray[turnCount].PropDetails(BoardVec, PlayerArray[turnCount].location);
                          //ui->textConsole->append(  "Press '1' to buy, '8' for property info, or '0' to skip: \n");
                          //cin >> BuyOrNo;
                      //}
                      //if (BuyOrNo == 1){ // IF BUYING
                         // if (PlayerArray[turnCount].Bal < BoardVec[PlayerArray[turnCount].location].Price){
                            //  ui->textConsole->append(  "You can't afford this property\n");
                         // }
                         // else{
                         //    // PlayerArray[turnCount].BuyProperty(PlayerArray, BoardVec, turnCount);
                          //}
                     // }
                 // }
              }
              if (ChanceRoll == 5){ // GO TO LAST RED
                  ui->textConsole->append(  "Move to Beard!\n");
                  num_till_destSquares=Squares_to_target(24);
                  MovePlayer(turnCount,num_till_destSquares + turnRoll);
                  PlayerArray[turnCount].PassedGO(turnCount, num_till_destSquares);
                  update_Summary();
                  alreadyMoved=true;
                  if(BoardVec[24].Owned==false){
                      BuyPrompt();
                  }
                  /*
                  if (PlayerArray[turnCount].location > 24){
                     // PlayerArray[turnCount].PassedGO(PlayerArray, BoardVec, turnCount);
                  }
                  PlayerArray[turnCount].location = 24;
                  if (BoardVec[PlayerArray[turnCount].location].Owned && BoardVec[PlayerArray[turnCount].location].OwnerID != turnCount){
                      //PlayerArray[turnCount].PayRent(PlayerArray, BoardVec, turnCount);
                  }
                  else if (!BoardVec[PlayerArray[turnCount].location].Owned){
                      ui->textConsole->append(  "Beard is unowned!\nPress '1' to buy\nPress '8' for property info\nPress '0' to skip\n");
                      ui->textConsole->append( QString::fromStdString( "Current balance: $" + std::to_string(PlayerArray[turnCount].Bal) + "\n"));
                      ui->textConsole->append( QString::fromStdString( "Cost: $" + std::to_string(BoardVec[PlayerArray[turnCount].location].Price) +  "\n"));
                      int BuyOrNo;
                     // cin >> BuyOrNo;

                      while (BuyOrNo == 8){
                         // PlayerArray[turnCount].PropDetails(BoardVec, PlayerArray[turnCount].location);
                          ui->textConsole->append(  "Press '1' to buy, '8' for property info, or '0' to skip: \n");
                          //cin >> BuyOrNo;
                      }
                      if (BuyOrNo == 1){ // IF BUYING
                          if (PlayerArray[turnCount].Bal < BoardVec[PlayerArray[turnCount].location].Price){
                              ui->textConsole->append(  "You can't afford this property\n");
                          }
                          else{
                              //PlayerArray[turnCount].BuyProperty(PlayerArray, BoardVec, turnCount);
                          }
                      }
                  }*/
              }
              if (ChanceRoll == 6){
                  ui->textConsole->append(  "GO TO JAIL\n");
                  num_till_destSquares=Squares_to_target(10);
                  MovePlayer(turnCount,num_till_destSquares + turnRoll);
                  alreadyMoved=true;
                  PlayerArray[turnCount].location = 10;
                  PlayerArray[turnCount].InJail = true;
              }
              if (ChanceRoll == 7){
                  ui->textConsole->append(  "Gain $50\n");
                  PlayerArray[turnCount].Bal = PlayerArray[turnCount].Bal + 50;
                  update_Summary();
                  ui->textConsole->append(QString::fromStdString(  "You now have: " + std::to_string(PlayerArray[turnCount].Bal) +  "\n"));
              }
              if (ChanceRoll == 8){
                  ui->textConsole->append(  "Gain $150\n");
                  PlayerArray[turnCount].Bal = PlayerArray[turnCount].Bal + 150;
                  update_Summary();
                 ui->textConsole->append(QString::fromStdString(  "You now have: " + std::to_string(PlayerArray[turnCount].Bal) +  "\n"));
              }
              if (ChanceRoll == 9){
                 // if (!PlayerArray[turnCount].CheckBankrupt(PlayerArray, BoardVec, turnCount, 15, 4)) {
                      //ui->textConsole->append(  "Pay $15\n");
                     // PlayerArray[turnCount].Bal = PlayerArray[turnCount].Bal - 15;
                     // ui->textConsole->append(QString::fromStdString(  "You now have: " + std::to_string(PlayerArray[turnCount].Bal) +  "\n"));
                 // }
              }
              if (ChanceRoll == 10){
                  ui->textConsole->append(  "Move forward 3 spaces\n");
                  MovePlayer(turnCount,3 + turnRoll);
                  alreadyMoved=true;
                  if (PlayerArray[turnCount].location == 7){
                      ui->textConsole->append(  "You have to pay Income Tax!\n");
                     //if (!PlayerArray[turnCount].CheckBankrupt(PlayerArray, BoardVec, turnCount, 15, 4)) {
                          //PlayerArray[turnCount].Bal -= 200;
                      //}
                      ui->textConsole->append(QString::fromStdString(  "You now have $" + std::to_string(PlayerArray[turnCount].Bal) + "\n"));
                  }
                  //PlayerArray[turnCount].location = 3;
                  if (BoardVec[PlayerArray[turnCount].location].Owned){
                     // PlayerArray[turnCount].PayRent(PlayerArray, BoardVec, turnCount);
                  }
                  else {
                      BuyPrompt();
                  }

              }
              if (ChanceRoll == 11){
                  ui->textConsole->append(  "Get out of jail free card!\n");
                  PlayerArray[turnCount].GOOJF = true;
              }
              if (ChanceRoll == 12 || ChanceRoll == 13){ // ADVANCE TO NEAREST RAILROAD NEEDS TESTING
                  ui->textConsole->append(  "Advance to nearest railroad\nIf owned pay double rent\n");
                  if (PlayerArray[turnCount].location == 7){
                      //PlayerArray[turnCount].location = 15;
                      num_till_destSquares=Squares_to_target(15);
                      alreadyMoved=true;
                      MovePlayer(turnCount, num_till_destSquares + turnRoll);
                      PlayerArray[turnCount].PassedGO(turnCount, num_till_destSquares);
                      update_Summary();
                      BuyPrompt();

                  }
                  else if (PlayerArray[turnCount].location == 22){

                      PlayerArray[turnCount].location = 25;
                      alreadyMoved=true;
                      num_till_destSquares=Squares_to_target(25);
                      MovePlayer(turnCount,num_till_destSquares + turnRoll);
                      PlayerArray[turnCount].PassedGO(turnCount, num_till_destSquares);
                      update_Summary();
                      BuyPrompt();
                  }
                  else  if (PlayerArray[turnCount].location == 36){
                      ui->textConsole->append(  "Advance to nearest railroad\nIf owned pay double rent\n");
                      num_till_destSquares=Squares_to_target(5);
                      alreadyMoved=true;
                      MovePlayer(turnCount,num_till_destSquares + turnRoll);
                      PlayerArray[turnCount].PassedGO(turnCount, num_till_destSquares);
                      update_Summary();
                      BuyPrompt();
                      //PlayerArray[turnCount].location = 5;
                      //PlayerArray[turnCount].Bal += 200; NOT SURE IF turnCount COLLECTS 200 FOR THIS - NOT SPECIFIED ON THE CARD   
                  }
              }
              if (ChanceRoll == 14){ // PAY EACH turnCount 50 DOLLARS
                  ui->textConsole->append(  "Pay each player $50\n");
                  for (int i = 0; i < 4; i++){
                      if (!PlayerArray[i].Bankrupt){
                          PlayerArray[turnCount].Bal -= 50;
                          PlayerArray[i].Bal += 50;
                      }
                  }
                  ui->textConsole->append(QString::fromStdString(  "You now have: " + std::to_string(PlayerArray[turnCount].Bal) + "\n"));
              }
              if (ChanceRoll == 15){ // PAY 25 FOR EACH HOUSE AND 100 FOR EACH HOTEL -- NEEDS TESTING
                  ui->textConsole->append(  "Pay $25 per house and $100 per hotel\n");
                  int Houses = 0;
                  int Hotels = 0;
                  for (int i = 0; i < 40; i++){
                      if (BoardVec[i].OwnerID == turnCount){
                          if (BoardVec[i].Hotel){
                              Hotels++;
                          }
                          else {
                              if (!BoardVec[i].isRailroad){
                                  Houses += BoardVec[i].numHouse;
                              }
                          }
                      }
                  }
                  std::string uhh= std::to_string( 40 * Houses + 115 * Hotels);
                  ui->textConsole->append( QString::fromStdString( "You owe $" + uhh + "\n"));
                  //if (!PlayerArray[turnCount].CheckBankrupt(PlayerArray, BoardVec, turnCount, 25 * Houses + 100 * Hotels, 4)) {
                      PlayerArray[turnCount].Bal -= (25 * Houses + 100 * Hotels);
                 // }
              }
              if (ChanceRoll == 16){ // ADVANCE TO NEAREST UTILITY -- NEEDS TESTING
                  ui->textConsole->append(  "Move to nearest utility. If owned roll dice and pay owner 10x roll\n");
                  if (PlayerArray[turnCount].location >= 27 || PlayerArray[turnCount].location < 12){
                      num_till_destSquares=Squares_to_target(12);
                      MovePlayer(turnCount,num_till_destSquares + turnRoll);
                      PlayerArray[turnCount].PassedGO(turnCount, num_till_destSquares);
                      update_Summary();
                      alreadyMoved=true;
                      BuyPrompt();
                     }
                  else {
                      num_till_destSquares=Squares_to_target(28);
                      MovePlayer(turnCount,num_till_destSquares + turnRoll);
                      PlayerArray[turnCount].PassedGO(turnCount, num_till_destSquares);
                      update_Summary();
                      alreadyMoved=true;
                      BuyPrompt();
                  }
              }
              if(!alreadyMoved){
                   alreadyMoved=false;
                   MovePlayer(turnCount,turnRoll);
              }
          }





